class_name LightSentinel
extends Area2D
## A guard that patrols back and forth between two points. It only exists in the
## MATERIAL realm (the mirror of the Shadow Wisp), so shifting realms lets you slip past it.
## The level creates sentinels with instantiate() when the stage starts.

# Custom signal (OS CONCEPT: Interrupts), connected in code by level.gd.
signal touched_player

@export var start_point: Vector2 = Vector2.ZERO
@export var end_point: Vector2 = Vector2.ZERO
@export var patrol_speed: float = 70.0

var _age: float = 0.0


func _ready() -> void:
	position = start_point
	GameState.note_spawned("sentinel")
	# OS CONCEPT: Interrupts - built-in body_entered signal connected through code.
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	# OS CONCEPT: CPU Scheduling - patrol movement and animation are frame-based (delta).
	_age += delta
	var length := start_point.distance_to(end_point)
	if length > 1.0:
		# pingpong() walks 0 -> length -> 0 -> length ... which makes the guard turn around.
		var travelled := pingpong(_age * patrol_speed, length)
		position = start_point.lerp(end_point, travelled / length)
	queue_redraw()


# Sentinels are visible and dangerous only while the player is in the Material Realm.
func set_active(active: bool) -> void:
	visible = active
	set_deferred("monitoring", active)


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		touched_player.emit()


func _draw() -> void:
	var pulse := 1.0 + sin(_age * 4.0) * 0.08
	draw_circle(Vector2.ZERO, 22.0 * pulse, Color("ffb86b", 0.12))
	var points := PackedVector2Array()
	for i in 8:
		var radius := 13.0 if i % 2 == 0 else 8.0
		points.append(Vector2.from_angle(_age * 1.2 + i * TAU / 8.0) * radius * pulse)
	draw_colored_polygon(points, Color("ffa94d"))
	draw_circle(Vector2.ZERO, 5.0, Color("fff1d6"))
	draw_arc(Vector2.ZERO, 17.0 * pulse, 0.0, TAU, 28, Color("ffd9a0", 0.7), 2.0)
